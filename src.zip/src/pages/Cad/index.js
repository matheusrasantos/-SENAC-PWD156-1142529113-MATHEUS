import { Link } from 'react-router-dom';
function Cad () {
    return (
            <div> 
                <h1>Pagina Cadastro </h1>
                <Link to='/'>Home</Link><br/>
            </div>
    )
}
export default Cad;