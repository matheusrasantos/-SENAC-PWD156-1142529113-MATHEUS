import { Link } from 'react-router-dom';
function Home () {
    return ( 
                <div style={{backgroundColor:"black"}}>
                    <h1> Pagina Home </h1>
                    <Link to='/'>Home</Link><br/>
                    <Link to='/cadastro'>Cadastro do Cliente</Link><br/>
                    <Link to='/contaCorrente'>Movimentacao da Conta Corrente</Link><br/>
                    <Link to='/calculoFinanciamento'>Calculo do Financiamento</Link><br/>
                    <Link to='/sobreNos'>Sobre Nós</Link><br/>
                </div>
    )
}
export default Home;