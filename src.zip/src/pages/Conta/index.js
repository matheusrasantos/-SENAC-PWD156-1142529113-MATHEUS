import { Link } from 'react-router-dom';
function Conta () {
    return (
            <div> 
                <h1>Pagina Movimentacao da Conta Corrente</h1>
                <Link to='/'>Home</Link><br/>
            </div>

    )
}
export default Conta;